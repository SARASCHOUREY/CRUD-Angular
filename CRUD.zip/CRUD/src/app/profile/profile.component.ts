import { HttpClient } from '@angular/common/http';
import { Emp } from './../Model/emp.model';
import { FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { registerService } from '../service/register-service';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { CompileShallowModuleMetadata } from '@angular/compiler';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  profileForm:FormGroup;
  employee:Emp
  id:number

  constructor(private http:HttpClient, private  rservice:registerService , private router:Router , private route: ActivatedRoute) { }

  ngOnInit() {
    this.id= this.route.snapshot.params['id'];
    this.rservice.getEmpById(this.id)
    .subscribe(
      employee=>{
        console.log(employee);
        this.employee = employee;
        console.log(this.employee);
      }
    );
  }


    OnDelete(id){
      this.http.delete(this.rservice.apiEndPoint+"/"+id)
      .subscribe(
        response=>{
          this.router.navigate(['/admin']);
          console.log(response);
        }
      )
    }
}
