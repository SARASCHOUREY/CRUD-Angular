import { ViewComponent } from './view/view.component';
import { PasswordchangeComponent } from './passwordchange/passwordchange.component';
import { ProfileComponent } from './profile/profile.component';
import { EmployeeComponent } from './employee/employee.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {path:'',component: LoginComponent},
  {path:'admin',component: AdminComponent},
  {path:'view/:id',component: ViewComponent},
  {path:'profile/:id',component: ProfileComponent},
  {path:'passwordchange/:id',component: PasswordchangeComponent},
  {path:'register',component: RegistrationComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
