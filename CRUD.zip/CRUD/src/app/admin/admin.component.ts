import { Component, OnInit } from '@angular/core';
import { renderService } from '../service/render-service';
import { Emp } from '../Model/emp.model';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  Emp:Emp[] = [];
  constructor(private rService:renderService) {
  }

  ngOnInit() {
    console.log("Inside put call")

    this.rService.getEmp()
        .subscribe(
          Employee=>{
            console.log("Inside get call")

            this.Emp=Employee
            console.log(Employee);
          }
        )
  }

}
