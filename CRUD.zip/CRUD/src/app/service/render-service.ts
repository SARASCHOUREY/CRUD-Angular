import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Emp } from './../Model/emp.model';
import { Observable } from 'rxjs';

@Injectable({
    providedIn:'root'
})

export class renderService{

    apiEndPoint = 'http://localhost:3000/employees'
    constructor(private http:HttpClient) { }

    getEmp(){
        console.log("Inside definition")
        return this.http.get<Emp[]>(this.apiEndPoint)
    }

}
