import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Emp } from './../Model/emp.model';
import { EmployeeComponent } from '../employee/employee.component';

//import {JwtHelper} from 'angular2-jwt';


@Injectable({
    providedIn:'root'
})

export class registerService{


  apiEndPoint = 'http://localhost:3000/employees'

     constructor(private http:HttpClient) { }

    employee:Emp[]=[];
    register(user){
        console.log("register Service")
        //console.log(user)
        return this.http.post(this.apiEndPoint, user)
      }
    
      login(user){
        console.log(user)
        return this.http.get(this.apiEndPoint, {params:{user_name:user}});
      }

      getEmp(){
        console.log("Inside definition")
        return this.http.get<Emp[]>(this.apiEndPoint)
    }
      // login(user){
      //   return this.http.get(this.apiEndPoint+'?user_name='+this.employee,{responseType:"json"});
      // }
    
      //  isLoggedIn(){
      //   let token = localStorage.getItem('token')
    
      //   if(!token)
      //       return false;
    
      //  let helper = new JwtHelper();
      //   return !helper.isTokenExpired(token)    
      // }

      getEmpById(id){
        console.log("Inside getempbyId")
        return this.http.get<Emp>(this.apiEndPoint+'/'+id,{responseType:"json"})
      }

      delete(id){
        return this.http.delete(this.apiEndPoint+'/'+id)
      }

      // updateEmp(id,emp)
      // {
      //   return this.http.put(this.apiEndPoint+'/'+id,emp)
      // }
      updateEmp(form)
      {
        return this.http.put(this.apiEndPoint+form.id,form)
      }
}
