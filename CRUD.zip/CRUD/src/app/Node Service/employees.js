var faker = require('faker');
faker.locale = "en_IND";

function generateEmployees () {
  var employees = []

  employees.push({
      "id": 0,
      "first_name": "Silicus",
      "last_name": "Admin",
      "user_name": "admin",
      "password":"admin",
      "address":"Pune IT Park, Bhau Patil Road",
      "city":"Pune",
      "state":"Maharashtra",
      "zip_code":"411020",
      "dob":"01-01-1980",
      "email": "admin@silicus.com",
      "phone_no":"8888888888",
	  "is_admin":true
    })
  
  for (var id = 1; id < 50; id++) {
    var firstName = faker.name.firstName()
    var lastName = faker.name.lastName()
    var username=faker.internet.userName()
    var password=faker.internet.password()
    var address=faker.address.streetAddress()
    var city=faker.address.city()
    var state=faker.address.state()
    var zipcode=faker.address.zipCode()
    var dob = faker.date.between('01-01-1980','12-31-1990')
    var email = faker.internet.email()
    var phone = faker.phone.phoneNumber()
	var isAdmin = false

    employees.push({
      "id": id,
      "first_name": firstName,
      "last_name": lastName,
      "user_name": username,
      "password":password,
      "address":address,
      "city":city,
      "state":state,
      "zip_code":zipcode,
      "dob":dob,
      "email": email,
      "phone_no":phone,
	  "is_admin":isAdmin
    })
  }
  
  

  return { "employees": employees }
}

module.exports = generateEmployees
