import { Component, OnInit } from '@angular/core';
import { Emp } from '../Model/emp.model';
import {FormGroup, FormBuilder} from '@angular/forms';
import { registerService } from '../service/register-service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

userForm:FormGroup;
registered:boolean  =false;

constructor(private fb:FormBuilder, private regService:registerService) { }

ngOnInit() {
  this.userForm = this.fb.group({
    SNo:[],
    EmpId:[],
    first_name:[],
    last_name:[],
    UserName:[],
    Phone:[],
    Password:[],
    City:[],
    State:[],
    Zip_Code:[],
    Address:[],
    Email:[],
    Is_admin:[]
})
}

onRegisterUser(){
  this.regService.register(this.userForm.value)
      .subscribe(
        response=>{
          console.log('User is Registered...!')
          this.registered = true;
          
        }
      )
}
}