import { Emp } from './../Model/emp.model';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { registerService } from '../service/register-service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  userForm: FormGroup;
  id: number

  employee: Emp
  constructor(private fb: FormBuilder, private router: Router, private activeroute: ActivatedRoute,
    private regservice: registerService) { }

  ngOnInit() {
    this.id = this.activeroute.snapshot.params['id'];

    this.userForm = this.fb.group({
      id: this.id,
      EmpId: [],
      Employee_FName: [],
      Employee_LName: [],
      UserName: [],
      Phone: [],
      Password: [],
      City: [],
      State: [],
      Zip_Code: [],
      Address: [],
      Email: [],
      Action: []
    });

    this.regservice.getEmpById(this.id)
    .subscribe(
    emp=>{
    this.employee=emp
    }
    )
  }


  Update() {
    console.log(this.userForm.value)
    this.regservice.updateEmp(this.userForm.value)
      .subscribe(
        response => {
          this.userForm.setValue(response);
        }
      )
  }

}
