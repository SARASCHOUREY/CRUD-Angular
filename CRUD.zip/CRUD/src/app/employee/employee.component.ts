import { Emp } from './../Model/emp.model';
import { Component, OnInit } from '@angular/core';
import { renderService } from '../service/render-service';
import { empty } from 'rxjs';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

 Emp:Emp[] = [];
//Emp:Object

  constructor(private rService:renderService) {
   }
 
  ngOnInit() {
    console.log("Inside put call")

    this.rService.getEmp()
        .subscribe(
          Employee=>{
            console.log("Inside get call")

            this.Emp=Employee
            console.log(Employee);
          }
        )
  }
}