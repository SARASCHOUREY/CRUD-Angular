import { Component, OnInit } from '@angular/core';
import { FormGroup ,FormBuilder, Validators} from '@angular/forms';
import { registerService } from '../service/register-service';
import { Router, ActivatedRoute, } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  loginError;
  loginForm:FormGroup;


   constructor(private fb:FormBuilder, 
               private regService:registerService,
               private router:Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      Username : [],
      Password : []
    })
  }
  onLogin(){
    console.log(this.loginForm);
    
    this.regService.login(this.loginForm.value['Username'])
        .subscribe(
          token=>{
            console.log(token);
            
            if(token[0].password==this.loginForm.value['Password'])
            {
            console.log('User Login Success...')
            console.log(token)
           // localStorage.setItem('token', token)
           console.log(token[0].is_admin);
           
            if(token[0].is_admin)
              this.router.navigate(['/admin']);
            else
              this.router.navigate(['/view']);
          }else{
              console.log('error')
          }
          });
        }}


