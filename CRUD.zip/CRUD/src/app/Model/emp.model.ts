export interface Emp{
    id:number
    EmpId:number
    first_name:string
    last_name:string
    UserName:string
    Phone:number
    Password:string
    State:string
    Zip_Code:number
    Address:string
    Email:string
    Contacts:number
    Action:string
    Is_admin:boolean
}

   
